#!/bin/sh

function print_usage
{
    echo "USAGE: *script* [-kit_path <path_to_DevMateKit>] [-app_bundle_id <application_bundle_id>] [-sign_ident <code_sign_identity>]"
}

KIT_PATH=""
APP_BUNDLE_ID=""
SING_IDENT=""
while test $# -gt 0; do
    case "$1" in
        -h|--help)
            print_usage
            exit 0
            ;;
        -kit_path)
            shift
            if test $# -gt 0; then
                KIT_PATH="$1"
            fi
            shift
            ;;
        -app_bundle_id)
            shift
            if test $# -gt 0; then
                APP_BUNDLE_ID="$1"
            fi
            shift
            ;;
        -sign_ident)
            shift
            if test $# -gt 0; then
                SIGN_IDENT="$1"
            fi
            shift
            ;;
        *)
            echo "Unknown input parameter \"$1\""
            break
            ;;
    esac
done

# try to get CODE_SIGN_IDENTITY from Xcode env and exit if fails
if [ -z "${SIGN_IDENT}" ]; then
    SIGN_IDENT="${EXPANDED_CODE_SIGN_IDENTITY_NAME}"
    if [ -z "${SIGN_IDENT}" ]; then
        echo "Code sign identity is absent. Please provide one for correct work."
        print_usage
        exit 1
    fi
fi

# try to get DevMateKit framework path and exit if fails
if [ -z "${KIT_PATH}" ]; then
    APP_BUILD_DIR="${TARGET_BUILD_DIR}"
    APP_FRAMEWORKS_DIR="${FRAMEWORKS_FOLDER_PATH}"
    if [ -z "${APP_BUILD_DIR}" -o -z "$APP_FRAMEWORKS_DIR" ]; then
        echo "Could not find path to DevMateKit.framework. Please, provide the correct one."
        print_usage
        exit 2
    fi

    KIT_PATH="${APP_BUILD_DIR}/${APP_FRAMEWORKS_DIR}/DevMateKit.framework"
fi

# try to get main product bundle identifier
while true; do
    # check bundle_id as input param
    if [ -n "${APP_BUNDLE_ID}" ]; then
        break
    fi

    # get bundle_id from Info.plist file if possible
    INFOPLIST_FULL_PATH="${TARGET_BUILD_DIR}/${INFOPLIST_PATH}"
    if [ -e "${INFOPLIST_FULL_PATH}" ]; then
        APP_BUNDLE_ID=`defaults read "${INFOPLIST_FULL_PATH}" CFBundleIdentifier`
        if [ -n "${APP_BUNDLE_ID}" ]; then
            break
        fi
    fi

    # check bundle_id as PRODUCT_BUNDLE_IDENTIFIER evnironment variable
    APP_BUNDLE_ID="${PRODUCT_BUNDLE_IDENTIFIER}"
    if [ -n "${APP_BUNDLE_ID}" ]; then
        break
    fi

    # use PRODUCT_NAME as bundle identifier
    APP_BUNDLE_ID="${PRODUCT_NAME}"
    if [ -n "${APP_BUNDLE_ID}" ]; then
        break
    fi

    # use UUID in case of all prev checks failed
    APP_BUNDLE_ID=`uuidgen`
    break
done

KIT_VERSION_PATH="${KIT_PATH}/Versions/A"
REPORTER_APP="${KIT_VERSION_PATH}/Resources/Problem Reporter Sandboxed.app"
echo "Will check path \"$REPORTER_APP\""
if [ ! -e "${REPORTER_APP}" ]; then
    echo "Could not find 'Problem Reporter Sandboxed.app' inside DevMateKit.framework. Please check framework integrity or provide correct path to it."
    print_usage
    exit 3
fi

REPORTER_PLIST="${REPORTER_APP}/Contents/Info.plist"
REPORTER_ENTITLEMENTS_TMP=$(mktemp)
if [ ! -f "${REPORTER_ENTITLEMENTS_TMP}" ]; then
    echo "Could not create temp file '${REPORTER_ENTITLEMENTS_TMP}' for 'Problem Reporter Sandboxed.app' entitlements inside DevMateKit.framework, aborting."
    exit 4
fi

codesign -d --entitlements "${REPORTER_ENTITLEMENTS_TMP}" "$REPORTER_APP"
RESULT=$?
if [ $RESULT != 0 ]; then
    echo "Could not extract 'Problem Reporter Sandboxed.app' entitlements inside DevMateKit.framework, aborting."
    exit 5
fi

REPORTER_OPTIONS=0x10000 # (runtime)

# correct APP_BUNDLE_ID if needs (replace all '_', ' ', '\', '/' with '-')
APP_BUNDLE_ID=${APP_BUNDLE_ID//[_ \\\/]/-}
OLD_BUNDLE_ID="com.devmate.Problem-Reporter-Sandboxed"
NEW_BUNDLE_ID="${APP_BUNDLE_ID}.${OLD_BUNDLE_ID}"
RESULT=0
while true; do
    defaults write "${REPORTER_PLIST}" CFBundleIdentifier -string "${NEW_BUNDLE_ID}"
    RESULT=$?
    if [ $RESULT != 0 ]; then
        break
    fi

    codesign -fv -s "${SIGN_IDENT}" --entitlements "${REPORTER_ENTITLEMENTS_TMP}" "${REPORTER_APP}" --options $REPORTER_OPTIONS
	rm "${REPORTER_ENTITLEMENTS_TMP}"

    RESULT=$?
    if [ $RESULT != 0 ]; then
        break
    fi

    codesign -fv -s "${SIGN_IDENT}" "${KIT_VERSION_PATH}"
    RESULT=$?
    break
done

if [ $RESULT != 0 ]; then
    defaults write "${REPORTER_PLIST}" CFBundleIdentifier -string "${OLD_BUNDLE_ID}"
fi

exit $RESULT
